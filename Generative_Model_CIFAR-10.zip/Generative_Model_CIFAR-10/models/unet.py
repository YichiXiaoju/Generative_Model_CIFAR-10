import torch
import torch.nn as nn
import torch.nn.functional as F
import math

# Time embedding function
class SinusoidalPositionEmbeddings(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim
        self.proj = nn.Sequential(
            nn.Linear(dim,4*dim),nn.SiLU(),
            nn.Linear(4*dim,dim)
        )
    
    def forward(self,t):
        half = self.dim // 2
        freqs = torch.exp(torch.linspace(math.log(1.0), math.log(10000.0), half, device=t.device))
        args = t[:, None] * freqs[None,:]
        emb = torch.cat([torch.sin(args), torch.cos(args)], dim=-1)
        if self.dim % 2 == 1:
            emb = torch.cat([emb, torch.zeros_like(emb[:,:1])], dim=-1)
        return self.proj(emb)
    
# Residual block with time embedding
class ResBlock(nn.Module):
    def __init__(self, c, tdim):
        super().__init__()
        self.norm1 = nn.GroupNorm(8, c)
        self.conv1 = nn.Conv2d(c,c,3,1,1)
        self.norm2 = nn.GroupNorm(8, c)
        self.conv2 = nn.Conv2d(c,c,3,1,1)
        self.time = nn.Sequential(nn.SiLU(),nn.Linear(tdim, c))

    def forward(self, x, t_emb):
        h = self.norm1(x)
        h = F.silu(h)
        h = self.conv1(h)
        h = self.norm2(h)
        h = h + self.time(t_emb)[:,:,None,None]
        h = F.silu(h)
        h = self.conv2(h)
        return x + h
    
# U-Net architecture
class TinyUNet(nn.Module):
    def __init__(self, base=64, time_dim=128, out_channels=3):
        super().__init__()
        self.time_mlp = SinusoidalPositionEmbeddings(time_dim)
        self.in_conv = nn.Conv2d(3, base, 3, 1, 1)
        # Downsampling layers
        self.down1 = nn.Conv2d(base, base*2, 3, 2, 1)
        self.res1 = ResBlock(base*2, time_dim)
        self.down2 = nn.Conv2d(base*2, base*4, 3, 2, 1)
        self.res2 = ResBlock(base*4, time_dim)
        # Bottleneck
        self.bottleneck = ResBlock(base*4, time_dim)
        # Upsampling layers
        self.up1 = nn.ConvTranspose2d(base*4, base*2, 4, 2, 1)
        self.res3 = ResBlock(base*2, time_dim)
        self.up2 = nn.ConvTranspose2d(base*2, base, 4, 2, 1)
        self.res4 = ResBlock(base, time_dim)
        self.out = nn.Conv2d(base, out_channels, 1)
    
    def forward(self, x, t_scalar):
        t = self.time_mlp(t_scalar)
        x = self.in_conv(x)
        x = self.down1(x)
        x = self.res1(x, t)
        x = self.down2(x)
        x = self.res2(x, t)
        x = self.bottleneck(x, t)
        x = self.up1(x)
        x = self.res3(x, t)
        x = self.up2(x)
        x = self.res4(x, t)
        return self.out(x)

# Example usage
if __name__ == "__main__":
    net = TinyUNet()
    x = torch.randn(4, 3, 32, 32)  # Example input (batch_size, channels, height, width)
    t = torch.randn(4)  # Example time input (batch_size, time_dim)
    output = net(x, t)
    print(output.shape)  # Should output (4, 3, 32, 32)