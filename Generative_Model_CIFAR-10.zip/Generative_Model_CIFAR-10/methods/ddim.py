import torch

@torch.no_grad()
def ddim_sample(net, alpha_bars, n=16, steps=50, eta=0.0, device="cuda"):
    """
    DDIM sampling.
    net: the trained noise prediction network (TinyUNet)
    alpha_bars: (T,), precomputed cumulative product of alphas
    eta: controls the scale of added noise (0.0 for deterministic)
    """

    T = alpha_bars.shape[0]
    ts = torch.linspace(T-1,0,steps,device=device).long()  # e.g. [999, 950, 900, ..., 0]
    x = torch.randn(n, 3, 32, 32, device=device)  # initial noise

    for i in range(len(ts)-1):
        t, t_next = ts[i], ts[i+1]
        a_t, a_t_next = alpha_bars[t], alpha_bars[t_next]

        t_b = torch.full((n,), t, device=device, dtype=torch.long)
        t_scalar = (t_b.float() + 1e-6) / (T - 1)

        # predict noise ε_theta(x_t, t)
        eps = net(x, t_scalar)
        x0_pred = (x - eps * (1 - a_t).sqrt()) / a_t.sqrt()  # predict x0
        x0_pred = x0_pred.clamp(-1, 1)  # clip to [-1, 1]

        sigma = eta * torch.sqrt((1 - a_t_next) / (1 - a_t) * (1 - a_t / a_t_next + 1e-8))
        dir_xt = torch.sqrt((1-a_t-sigma**2)) * eps  # direction pointing to x_t
        x = torch.sqrt(a_t_next) * x0_pred + dir_xt
        if eta > 0:
            noise = torch.randn_like(x)
            x = x + sigma * noise
    return x
