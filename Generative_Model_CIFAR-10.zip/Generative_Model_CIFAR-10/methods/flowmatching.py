import torch
import torch.nn.functional as F

@torch.no_grad()
def sample_xt(x0,x1,t):
    """
    Flow matching sampling step.
    x0: (n,3,32,32) tensor, starting point
    x1: (n,3,32,32) tensor, ending point
    t: (n,) tensor in [0,1], time steps
    returns: (n,3,32,32) tensor, sampled intermediate points
    """
    t = t.view(-1,1,1,1)
    xt = (1-t)*x0 + t*x1
    return xt

def training_loss_flowmatching(model,x0):
    """
    Compute the flow matching training loss.
    model: the trained vector field network (TinyUNet)
    x0: (n,3,32,32) tensor, starting points (data samples)
    returns: scalar tensor, the training loss
    """
    batch_size = x0.shape[0]
    device = x0.device

    # sample x1 from standard normal
    x1 = torch.randn_like(x0)

    # sample t uniformly in [0,1]
    t = torch.rand(batch_size, device=device)

    # compute xt
    xt = sample_xt(x0,x1,t)

    # predict vector field v_theta(xt,t)
    vt = model(xt, t)  # (n,3,32,32)

    # compute target vector field
    vt_target = x1 - x0  # (n,3,32,32)

    loss = F.mse_loss(vt, vt_target)
    return loss