import torch
import torch.nn.functional as F

def phi_linear(t):
    """
    Linear interpolation function phi(t) = t
    t: (n,) tensor in [0,1]
    returns: (n,) tensor
    """
    return t

def dphi_linear(t):
    """
    Derivative of linear interpolation function dphi(t) = 1
    t: (n,) tensor in [0,1]
    returns: (n,) tensor
    """
    return torch.ones_like(t)

"""
you can define other interpolation functions here, e.g., quadratic, cubic, etc.
def phi_quadratic(t):
    return t**2

def dphi_quadratic(t):
    return 2*t
"""
phi = phi_linear
dphi = dphi_linear

@torch.no_grad()
def interp_xt(x0,x1,t):
    """
    Rectified flow interpolation step.
    t: [B,] in [0,1]
    xt = (1-phi(t)) * x0 + phi(t) * x1
    """

    if t.dim() == 1:
        t = t.view(-1,1,1,1)
    phi_t = phi(t)
    xt = (1-phi_t)*x0 + phi_t*x1
    return xt

def training_loss_rectified_flow(model,x0):
    """
    Compute the rectified flow training loss.
    model: the trained vector field network (TinyUNet)
    x0: (n,3,32,32) tensor, starting points (data samples)
    returns: scalar tensor, the training loss
    L = E[ || v_theta(xt,t) - dphi(t)*(x1-x0) ||^2 ]
    where xt = (1-phi(t))*x0 + phi(t)*x1, t~U[0,1], x1~N(0,I)
    """
    batch_size = x0.shape[0]
    device = x0.device

    # sample x1 from standard normal
    x1 = torch.randn_like(x0)

    # sample t uniformly in [0,1]
    t = torch.rand(batch_size, device=device)
    t_net = t
    t_field = t[:,None,None,None]

    # compute xt
    x1 = torch.randn_like(x0)
    xt = interp_xt(x0,x1,t)

    # predict vector field v_theta(xt,t)
    v_true = dphi(t_field) * (x1 - x0)  # (n,3,32,32)
    vt = model(xt, t_net)  # (n,3,32,32)

    loss = F.mse_loss(vt, v_true)
    return loss

@torch.no_grad()
def ode_step_heun(model,x,t,dt):
    """
    Heun: x_{k+1} = x_k + 0.5*(v_k+v_{k+1_pred})*dt
    """
    B = x.shape[0]
    t_b = torch.full((B,), t, device=x.device, dtype=torch.float32)
    v1 = model(x, t_b)  # (B,3,32,32)
    x_pred = x + v1 * dt  # Euler step
    t_next = t + dt
    t_next_b = torch.full((B,), t_next, device=x.device, dtype=torch.float32)
    v2 = model(x_pred, t_next_b)  # (B,3,32,32)
    x_next = x + 0.5 * (v1 + v2) * dt
    return x_next