import torch
import torch.nn.functional as F

def q_sample(x0, t_int, alpha_bars, noise=None):
    """
    Diffusion forward process: q(x_t | x_0)
    x0: original images, shape (B, 3, 32, 32)
    t_int: time step, shape (B,) int64 in [0, T-1]
    alpha_bars: precomputed cumulative product of (1 - beta) for each time step, shape (T,)
    noise: optional noise, shape (B, 3, 32, 32), N(0,1)
    """
    if noise is None:
        noise = torch.randn_like(x0)
    sqrt_alpha_bars = torch.sqrt(alpha_bars[t_int])[:, None, None, None]
    sqrt_one_minus_alpha_bars = torch.sqrt(1 - alpha_bars[t_int])[:, None, None, None]
    return sqrt_alpha_bars * x0 + sqrt_one_minus_alpha_bars * noise

def training_loss(net, x0, t_int, alpha_bars):
    """
    Compute the training loss for DDPM
    net: the neural network model
    x0: original images, shape (B, 3, 32, 32)
    t_int: time step, shape (B,) int64 in [0, T-1]
    alpha_bars: precomputed cumulative product of (1 - beta) for each time step, shape (T,)
    """
    eps = torch.randn_like(x0)
    xt = q_sample(x0, t_int, alpha_bars, eps)
    # project t_int to [0, 1] for time embedding
    t_scalar = (t_int.float() + 1e-6) / (alpha_bars.shape[0] - 1)
    predicted_noise = net(xt, t_scalar)
    return F.mse_loss(predicted_noise, eps)

# Example usage
if __name__ == "__main__":
    from models.unet import TinyUNet
    from utils.schedules import make_beta_schedule, compute_alphas

    B = 4
    T = 1000
    betas = make_beta_schedule(T)
    _, alpha_bars = compute_alphas(betas)

    net = TinyUNet()
    x0 = torch.randn(B,3,32,32)
    t_int = torch.randint(0, T, (B,))
    loss = training_loss(net, x0, t_int, alpha_bars)
    print("loss =", loss.item())
