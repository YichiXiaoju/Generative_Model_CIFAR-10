import torch

def make_beta_schedule(T: int, beta_start: float = 1e-4, beta_end: float = 0.02) -> torch.Tensor:
    """
    Linear beta schedule: length T, tensor on CPU (调用方可 .to(device)).
    """
    return torch.linspace(beta_start, beta_end, steps=T)

def compute_alphas(betas: torch.Tensor):
    """
    Given betas (T,), return:
    alphas:      1 - betas
    alpha_bars:  cumulative product of alphas
    """
    alphas = 1.0 - betas
    alpha_bars = torch.cumprod(alphas, dim=0)
    return alphas, alpha_bars
    
def make_beta_schedule_cosine(T: int, s: float = 0.008):
    steps = T + 1
    t = torch.linspace(0, T, steps) / T
    a = torch.cos((t + s) / (1 + s) * 3.1415926535 / 2) ** 2
    a = a / a[0]
    betas = 1 - (a[1:] / a[:-1])
    return betas.clamp(1e-8, 0.999)