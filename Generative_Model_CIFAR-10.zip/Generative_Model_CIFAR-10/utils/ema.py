from copy import deepcopy
import torch

class EMA:
    """Exponential Moving Average of model parameters."""
    def __init__(self, model, decay: float = 0.999):
        self.ema = deepcopy(model).eval()
        self.decay = decay
        for p in self.ema.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        d = self.decay
        for p_ema, p in zip(self.ema.parameters(), model.parameters()):
            p_ema.data.mul_(d).add_(p.data, alpha=1.0 - d)

    def state_dict(self):
        return self.ema.state_dict()
